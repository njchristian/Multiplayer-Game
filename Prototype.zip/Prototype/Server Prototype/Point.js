
function Point(x, y){
	this.x = x;
	this.y = y;
}